import React from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  StyleSheet,
  ScrollView
} from 'react-native';

import {
  Eye,
  Ear,
  Hand,
  MapPin,
  Navigation,
  Headphones
} from 'lucide-react-native';

export default function Recursos({ navigation, route }) {

  // 🔥 Recebe o nome vindo da tela anterior
  const nomeUsuario = route?.params?.nome || "Usuário";

  const recursos = [
    {
      titulo: "Leitor de Texto",
      descricao: "Converta texto em áudio",
      icon: <Eye size={22} color="#8B5CF6" />,
      tela: "LeitorTexto"
    },
    {
      titulo: "Reconhecimento de Voz",
      descricao: "Controle por voz",
      icon: <Ear size={22} color="#3B82F6" />,
      tela: "ReconhecimentoVoz"
    },
    {
      titulo: "Libras",
      descricao: "Tradução para Libras",
      icon: <Hand size={22} color="#10B981" />,
      tela: "Libras"
    },
    {
      titulo: "Locais",
      descricao: "Locais acessíveis",
      icon: <MapPin size={22} color="#F59E0B" />,
      tela: "Locais"
    },
    {
      titulo: "Navegação",
      descricao: "Navegação assistida",
      icon: <Navigation size={22} color="#EC4899" />,
      tela: "NavegacaoAssistida"
    },
    {
      titulo: "Suporte",
      descricao: "Atendimento acessível",
      icon: <Headphones size={22} color="#6366F1" />,
      tela: "Suporte"
    },
  ];

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>

      {/* 👤 PERFIL */}
      <View style={styles.profile}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>
            {nomeUsuario.charAt(0).toUpperCase()}
          </Text>
        </View>

        <View>
          <Text style={styles.nome}>
            {nomeUsuario}
          </Text>
          <Text style={styles.sub}>Bem-vindo 👋</Text>
        </View>
      </View>

      {/* 🔵 TÍTULO */}
      <Text style={styles.title}>Recursos de Acessibilidade</Text>

      {/* 🧩 GRID */}
      <View style={styles.grid}>
        {recursos.map((item, index) => (
          <TouchableOpacity
            key={index}
            style={styles.card}
            onPress={() => navigation.navigate(item.tela)}
          >
            {item.icon}

            <Text style={styles.cardTitle}>{item.titulo}</Text>
            <Text style={styles.cardText}>{item.descricao}</Text>
          </TouchableOpacity>
        ))}
      </View>

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FB',
  },

  content: {
    padding: 20,
  },

  // 👤 Perfil
  profile: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 20,
  },

  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: "#2F5DFF",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 10,
  },

  avatarText: {
    color: "#FFF",
    fontSize: 20,
    fontWeight: "bold",
  },

  nome: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#333",
  },

  sub: {
    fontSize: 13,
    color: "#777",
  },

  // 🔵 Título
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#2F5DFF',
  },

  // 🧩 Grid
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },

  card: {
    width: '47%',
    height: 150,
    backgroundColor: '#FFF',
    borderRadius: 18,
    padding: 16,
    marginBottom: 10,

    borderWidth: 2,
    borderColor: '#2F5DFF',

    elevation: 3,
  },

  cardTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2F5DFF',
    marginTop: 10,
    marginBottom: 4,
  },

  cardText: {
    fontSize: 13,
    color: '#666',
  }
});